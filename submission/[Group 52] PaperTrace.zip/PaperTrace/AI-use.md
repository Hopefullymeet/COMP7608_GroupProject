# Project AI assistance


## Declaration

OpenAI Codex helped revise the runtime prompts and test how PaperTrace selects the response language for each question.

OpenAI Codex also checked the submission README against the desktop workflows and diagnosed the Windows PowerShell SDK detection issue while testing the build instructions.

OpenAI Codex (GPT-6) synchronized the submission with the model-provider changes and updated the setup instructions and illustrated guide.

Anthropic Claude (Opus 5.5) helped revised the report.

## Project-related prompts

**Response-language update (Codex, 2026-11-24).** Original user prompt:

> 我发现一个问题，有些有时候我是用英文提问，回答的是中文。请将所有提示词无损转成英文，同时注意提示按用户语言回答问题，不是固定一种语言。

**Submission update (same chat).** Original user prompt:

> 针对此次的更新，对应更新submission中的内容（包括zip）

**Submission README and illustrated guide (Codex, 2026-11-24).** Original user prompts:

> 当前README里存在一些描述冗余，又存在一些使用等流程没有被纳入/不准确，请按要求重写README，保证流程正确。若可行，可以考虑增加一个USER_GUIDE以LaTeX编译PDF形式，辅以截图来说明完整的应用功能。

**Model provider submission update (Codex, 2026-11-25).** Original user prompt:

> 目前我本地的代码和部分流程有改变，请你更新submission里对应需要更新的部分，包括但不限于代码更新/流程（模型配置部分流程）更新（若有需要，在README和USERGUIDE里仅更新改动部分，不要改变整体结构）。

**Final report draft (Claude Opus 5.5 in Claude Code, 2026-11-25).** Claude checked the report requirements against the repository, exported the live desktop task traces to `evaluation/live_traces.json`, and drafted the LaTeX report. Original user prompts:

> 按照老师的要求，现在要完成最后report的撰写。如果需要撰写，请你检查目前我们有哪些缺少的资料？现在可以撰写完成哪些部分？

> 关于真实轨迹部分，难道我的几条实际提问不算是真实轨迹吗？

> 尽量使用完整内容PDF作示例，不要用你刚刚使用的那一段摘要。
