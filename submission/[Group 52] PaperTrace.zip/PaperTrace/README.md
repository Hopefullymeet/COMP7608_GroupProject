# PaperTrace

**HKU COMP7608B · Group 52**  
Gong Xiangwei, Hou Jiachen, Ning Ziyang and Wang Yao  
Desktop 0.1.0 · based on source revision `f84aee37`.

PaperTrace helps researchers check an answer against the paper it came from. Its agent searches the papers in a topic, reads passages and verifies quotes before linking them to an answer. Papers, notes and conversations stay in a local workspace. [Illustrated user guide](USER_GUIDE.pdf)

## Build and launch

Extract the **entire ZIP** into a writable folder. Run these commands from the extracted `PaperTrace` directory. Allow several GB of disk space and internet access for the first build. A CPU is sufficient for the walkthrough and tests.

| | Windows x64 · PowerShell | macOS Intel or Apple Silicon · Terminal |
|---|---|---|
| Build | `.\Build-Windows.cmd` | `bash ./Build-macOS.command` |
| Launch | `.\release\papertrace.exe` | `open frontend/src-tauri/target/release/bundle/macos/PaperTrace.app` |

**Windows.** The launcher checks for MSVC, a Windows SDK, WebView2, Rust and uv. Follow any installer or restart prompt and rerun. If WinGet is missing, install **App Installer**. Keep `papertrace.exe`, `runtime.tar.gz` and `runtime.sha256` together. The Windows desktop client was tested with two saved providers and a separate evidence reviewer on localhost. Clean-machine prerequisite installation remains unverified.

**macOS.** If prompted, finish installing Apple Command Line Tools and rerun. The launcher prepares native Rust and uv. For a custom Cargo target directory, use the app path printed after `Built`. The Mac launcher passed a syntax check. A native build of this snapshot is pending.

| Dependency | Submitted configuration |
|---|---|
| Build and UI | Node 24 (24.14.0 fallback), pnpm 12.4.2, stable Rust, Tauri 2.12.7, React 18.3.1 and Vite 5.4.21 |
| Bundled worker | CPython 3.12.13, pypdf 6.4.0, PyMuPDF 1.26.5 and pybtex 0.26.1 |
| Local OCR and figure search | English and simplified Chinese OCR data, quantized Chinese-CLIP model (191 MB download during build) |

## Try one paper

1. **Connect your model.** At first launch or under **Settings → Model**, click **Add model provider**. Enter a provider name, an OpenAI-compatible base URL (include `/v1` if required), a model ID that supports tool calls and your API key. PaperTrace appends `/chat/completions`. Click **Save connection**. Under **Settings → Model**, choose the saved name in **Model provider** and click **Test selected provider**. Use **Manage providers** to edit or delete connections. The worker can also use `DEEPSEEK_API_KEY` from its launch environment. Live requests send relevant paper material to the provider and can incur charges. **Set up later** lets you import and read offline.
2. **Import a paper.** On the home screen, click **New topic**, enter a name and drop the supplied QASPER PDF under **Starting papers**. Leave **Starting question** blank. **Create topic** imports the file and opens **Read & ask**. [QASPER sample](data-preparation/corpus/qasper/paper.pdf)
3. **Ask and verify.** Send *What do QASPER question writers read, and who supplies answers and evidence?* Sending starts the task using all readable paper versions in this topic. Click a numbered source. The abstract on PDF page 1 says that question writers saw the title and abstract, and separate NLP practitioners provided answers and evidence.
4. **Change the request.** In the same conversation ask *Focus only on the question writers. Which parts could they see?* Try *提问者能看到论文的哪些部分？* to check that the explanation switches language while the supporting quote still matches the source.

For online discovery, start a topic with a **Starting question** and no PDF. In **Discover**, select **Find papers** and confirm the OpenAlex request. Network access and provider quota affect results. For PDF annotations, figure search, comparison, Wiki and manuscript citation checks, follow the [user guide](USER_GUIDE.pdf).

## Reproduce the checks

Run these commands with uv and Node 24 available after setup. The replay also finds the private Node installation downloaded by the launcher. Neither check needs a model key.

```sh
uv run --no-project --managed-python --python 3.12.13 --with pypdf==6.4.0 -- python -X utf8 -B evaluation/run.py --output replay.json
uv run --no-project --managed-python --python 3.12.13 -- python -X utf8 -B data-preparation/validate_data.py
```

| Replay input | Passing observation |
|---|---|
| Ask which benchmark Alpha defines | Its citation resolves to the matching quote on Alpha page 1. |
| Switch to Beta only in the same session | The citation resolves to Beta page 1 and its different test split. |
| Inject malformed model output after tool use | The task stops with `MODEL_OUTPUT_INVALID` and saves no answer. |

**Results.** All three cases passed using the production worker, SQLite and Node agent loop against a scripted localhost provider. The corpus validator checked 18 PDFs, 249 pages, 84 pilot cases, 14 relations and 152 evidence spans. [Replay inputs](evaluation/cases.json) · [Recorded tool steps, quotes and outcomes](evaluation/results.json) · [Corpus manifest](data-preparation/manifest.json)

**Client fixtures.** With Node 24, npm and pnpm 12.4.2 on PATH and the frontend dependencies installed by the build, run the seven workspace tests and eight baseline scenarios.

```sh
pnpm --dir frontend test
npm ci --prefix tests/baseline
npm test --prefix tests/baseline
```

**Live evaluation.** See the [report evaluation instructions](evaluation/experiments/README.md) for offline scoring, live collection, and a worked example of assembling and scoring fresh results.

The browser demo (`pnpm --dir frontend dev`, then `http://localhost:5174/?mode=contract`) uses fixtures, including its Markdown revision/export, backup and external-access screens. The desktop citation workflow accepts PDF manuscripts. [Agent instructions](backend/agent.md) · [Model and tool calls](backend/model_agent.py) · [Third-party attribution](docs/third-party/README.md) · [AI-use record](AI-use.md)

## Optional: GitHub and preview installers

[GitHub repository](https://github.com/Hopefullymeet/COMP7608_GroupProject) · [GitHub Release v0.1.0-preview.1](https://github.com/Hopefullymeet/COMP7608_GroupProject/releases/tag/v0.1.0-preview.2)

- **Windows x64** — Download and run the [`.exe` installer](https://github.com/Hopefullymeet/COMP7608_GroupProject/releases/download/v0.1.0-preview.1/PaperTrace_0.1.0_x64-setup.exe).
- **macOS Apple Silicon** — Open the downloaded [`.dmg` installer](https://github.com/Hopefullymeet/COMP7608_GroupProject/releases/download/v0.1.0-preview.1/PaperTrace_0.1.0_aarch64.dmg) and drag PaperTrace into Applications.
