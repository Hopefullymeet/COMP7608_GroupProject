"""Build PaperTrace for the current host. Started by either OS launcher."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory
from urllib.request import urlopen
import zipfile

ROOT = Path(__file__).resolve().parent
FRONT = ROOT / "frontend"
CACHE = ROOT / ".papertrace-build"
WINDOWS = sys.platform == "win32"
NODE = "24.14.0"
PNPM = "12.4.2"


def run(*args, cwd=ROOT):
    print("+", " ".join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), cwd=cwd, check=True)


def output(*args, cwd=ROOT):
    return subprocess.check_output(args, cwd=cwd, text=True).strip()


def add_path(directory):
    os.environ["PATH"] = str(directory) + os.pathsep + os.environ["PATH"]


def download(url, destination):
    print("Downloading", url, flush=True)
    temp = destination.with_suffix(destination.suffix + ".part")
    with urlopen(url, timeout=120) as response, temp.open("wb") as dest:
        shutil.copyfileobj(response, dest)
    temp.replace(destination)


def native_node(arch):
    node = shutil.which("node")
    if node and shutil.which("npm") and output(node, "-p", "process.versions.node.split('.')[0] + '-' + process.arch") == "24-" + arch:
        return
    system = "win" if WINDOWS else "darwin"
    stem = f"node-v{NODE}-{system}-{arch}"
    filename = stem + (".zip" if WINDOWS else ".tar.gz")
    node_bin = CACHE / stem if WINDOWS else CACHE / stem / "bin"
    if not (node_bin / ("node.exe" if WINDOWS else "node")).is_file():
        base = f"https://nodejs.org/dist/v{NODE}/"
        with TemporaryDirectory(dir=CACHE) as tmp:
            files = Path(tmp)
            checks = urlopen(base + "SHASUMS256.txt", timeout=60).read().decode().splitlines()
            expected, = [line.split()[0] for line in checks if line.split()[-1] == filename]
            archive = files / filename
            download(base + filename, archive)
            with archive.open("rb") as handle:
                if hashlib.file_digest(handle, "sha256").hexdigest() != expected:
                    raise ValueError("Node.js archive checksum mismatch")
            if WINDOWS:
                with zipfile.ZipFile(archive) as z:
                    z.extractall(files)
            else:
                with tarfile.open(archive) as tar:
                    tar.extractall(files, filter="data")
            (files / stem).rename(CACHE / stem)
    add_path(node_bin)


def package_manager():
    pnpm = shutil.which("pnpm.cmd" if WINDOWS else "pnpm") or shutil.which("pnpm")
    if pnpm and output(pnpm, "--version") == PNPM:
        return pnpm
    prefix = CACHE / "tools"
    bin_dir = prefix if WINDOWS else prefix / "bin"
    local = bin_dir / ("pnpm.cmd" if WINDOWS else "pnpm")
    if not local.is_file() or output(local, "--version") != PNPM:
        npm = shutil.which("npm.cmd" if WINDOWS else "npm")
        run(npm, "install", "--global", "--prefix", prefix, "--cache", CACHE / "npm-cache", "--no-audit", "--no-fund",
            "--registry=https://registry.npmjs.org/", "pnpm@" + PNPM)
    add_path(bin_dir)  # Tauri's beforeBuildCommand also invokes pnpm.
    return str(local)


def build(vision):
    machine = platform.machine().lower()
    arch = {"arm64": "arm64", "aarch64": "arm64", "amd64": "x64", "x86_64": "x64"}.get(machine)
    if not (WINDOWS and arch == "x64" or sys.platform == "darwin" and arch):
        sys.exit("Build on Windows x64 or macOS (Intel / Apple Silicon).")
    triple = "x86_64-pc-windows-msvc" if WINDOWS else ("aarch64" if arch == "arm64" else "x86_64") + "-apple-darwin"
    if not shutil.which("rustc") or not shutil.which("cargo") or "host: " + triple not in output("rustc", "-vV").splitlines():
        sys.exit(f"Install the native Rust stable toolchain ({triple}) as described in README.md.")
    CACHE.mkdir(exist_ok=True)
    native_node(arch)
    pnpm = package_manager()
    run(pnpm, "install", "--frozen-lockfile", "--registry=https://registry.npmjs.org/", cwd=FRONT)
    scratch = CACHE / "runtime"
    scratch.mkdir(exist_ok=True)
    node_bin = Path(output("node", "-p", "process.execPath")).parent
    license_file = scratch / "NODE-LICENSE"
    version = output("node", "-p", "process.version")
    if not any(p.is_file() for p in (node_bin / "LICENSE", node_bin.parent / "LICENSE")):
        cached = CACHE / ("NODE-LICENSE-" + version)
        if not cached.exists():
            download(f"https://raw.githubusercontent.com/nodejs/node/{version}/LICENSE", cached)
        shutil.copyfile(cached, license_file)
    run(sys.executable, "-I", FRONT / "scripts/release-runtime.py", scratch)
    config = "portable" if WINDOWS else "release"
    args = ["--no-bundle"] if WINDOWS else ["--bundles", "app"]
    run(pnpm, "exec", "tauri", "build", "--features", "bundled-runtime", "--config",
        f"src-tauri/tauri.{config}.conf.json", *args, "--", "--locked", cwd=FRONT)
    if WINDOWS:
        run("node", "scripts/publish-exe.mjs", cwd=FRONT)
        app = ROOT / "release/papertrace.exe"
    else:
        metadata = json.loads(output("cargo", "metadata", "--format-version", "1", "--no-deps", cwd=FRONT / "src-tauri"))
        app = Path(metadata["target_directory"]) / "release/bundle/macos/PaperTrace.app"
    if not app.exists():
        raise FileNotFoundError(app)
    print("Built", app, flush=True)
    if vision:
        if not shutil.which("ollama"):
            sys.exit("Application built. Install and start Ollama, then run: ollama pull qwen3-vl:2b")
        run("ollama", "pull", "qwen3-vl:2b")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--with-ollama", action="store_true", help="Also pull the optional local image-description model")
    build(parser.parse_args().with_ollama)
