@echo off
setlocal
cd /d "%~dp0" || exit /b 1
set "PATH=%USERPROFILE%\.cargo\bin;%LOCALAPPDATA%\Microsoft\WinGet\Links;%USERPROFILE%\.local\bin;%PATH%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File Prepare-Windows.ps1 || goto failed
where rustup.exe >nul 2>&1 && set "RUSTUP_TOOLCHAIN=stable-x86_64-pc-windows-msvc"
uv run --no-project --managed-python --python 3.12.13 -- python -I build.py %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo Build stopped. See the error above and the prerequisites in README.md.
if not defined CI pause
exit /b 1
