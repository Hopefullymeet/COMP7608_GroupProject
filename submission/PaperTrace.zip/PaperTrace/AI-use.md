# Project AI assistance

**Draft for Group 52 to complete before submission.**

## Declaration

OpenAI Codex helped revise the runtime prompts and test how PaperTrace selects the response language for each question.

OpenAI Codex also checked the submission README against the desktop workflows, captured the guide's screenshots, prepared the LaTeX guide, and diagnosed the Windows PowerShell SDK detection issue while testing the build instructions.

OpenAI Codex (GPT-6) synchronized the submission with the model-provider changes and updated the setup instructions and illustrated guide.

[List each AI tool and model used for this project. Give the recorded model/version where available and briefly describe the work it helped with.]

## Project-related prompts

**Response-language update (Codex, 2026-11-24).** Original user prompt:

> 我发现一个巨大问题，有些有时候我是用英文提问，回答的是中文。请将所有提示词无损转成英文，同时注意提示按用户语言回答问题，不是固定一种语言。

**Submission update (same chat).** Original user prompt:

> 针对此次的更新，对应更新submission中的内容（包括zip）

**Submission README and illustrated guide (Codex, 2026-11-24).** Original user prompts:

> 当前README里存在一些描述冗余，又存在一些使用等流程没有被纳入/不准确，请按要求重写README，保证流程正确。若可行，你可以考虑增加一个USER_GUIDE以LaTeX编译PDF形式，辅以截图来说明完整的应用功能。

> 我说的README，是提交目录下的，你所进行的都是在提交目录下

**Model provider submission update (Codex, 2026-11-25).** Original user prompt:

> 目前我本地的代码和部分流程有改变，请你更新submission里对应需要更新的部分，包括但不限于代码更新/流程（模型配置部分流程）更新（若有需要，在README和USERGUIDE里仅更新改动部分，不要改变整体结构）。

**Final report draft (Claude Opus 5.5 in Claude Code, 2026-11-25).** Claude checked the report requirements against the repository, exported the live desktop task traces to `evaluation/live_traces.json`, and drafted the LaTeX report. Original user prompts:

> 按照老师的要求，现在要完成最后report的撰写。如果需要撰写，请你检查目前我们有哪些缺少的资料？现在可以撰写完成哪些部分？

> 关于真实轨迹部分，难道我的几条实际提问不算是真实轨迹吗？

> 好，在submission目录下开始写吧，注意按老师要求，同时使用指定模板，英文，去AI味。

> 尽量使用完整内容PDF作示例，不要用你刚刚使用的那一段摘要。

[Paste each available project prompt or link to its accompanying text file in this ZIP. Group the records by tool or task. Remove credentials and personal information. Omit AI responses.]

## Missing records

[Identify any missing prompts, dates or model identifiers, and the affected tasks. If the records are complete, state that here.]
