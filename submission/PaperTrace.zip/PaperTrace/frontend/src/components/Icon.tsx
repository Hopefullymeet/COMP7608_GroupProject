const PATHS: Record<string, JSX.Element> = {
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
  plus: <path d="M12 5v14M5 12h14" />,
  edit: <><path d="m14 6 4 4M4 20l4-.8L20 7l-4-4L4.8 15z" /></>,
  trash: <><path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7" /></>,
  file: <><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" /><path d="M14 3v5h5M9 13h6M9 17h4" /></>,
  message: <path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z" />,
  messageDots: <><path d="M21 11.5a8.5 8.5 0 0 1-12.3 7.6L3 21l1.6-5A8.5 8.5 0 1 1 21 11.5Z" /><path d="M8 11.5h.01m4-.01h.01m4-.01h.01" strokeLinecap="round" strokeWidth="2.6" /></>,
  paperList: <path d="M4 6h16M4 12h13M4 18h9" />,
  arrowDown: <path d="M12 5v14m-6-6 6 6 6-6" />,
  zoomIn: <><circle cx="10" cy="10" r="6.5" /><path d="m15 15 5 5M7 10h6m-3-3v6" /></>,
  zoomOut: <><circle cx="10" cy="10" r="6.5" /><path d="m15 15 5 5M7 10h6" /></>,
  more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
  arrowUp: <path d="M12 19V5M6 11l6-6 6 6" />,
  arrowLeft: <path d="M19 12H5M11 6l-6 6 6 6" />,
  arrowRight: <path d="M5 12h14M13 6l6 6-6 6" />,
  refresh: <path d="M20 4v5h-5M4 20v-5h5m11-6a8 8 0 0 0-13.5-3M4 15a8 8 0 0 0 13.5 3" />,
  compass: <><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2 5-5 2 2-5z" /></>,
  globe: <><circle cx="12" cy="12" r="9" /><ellipse cx="12" cy="12" rx="4" ry="9" /><path d="M3 12h18" /></>,
  book: <path d="M2 5h6a4 4 0 0 1 4 4v11a3 3 0 0 0-3-3H2zM22 5h-6a4 4 0 0 0-4 4v11a3 3 0 0 1 3-3h7z" />,
  columns: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M12 4v16" /></>,
  trace: <><path d="m6 17 4-5m4-2 4-5" /><circle cx="5" cy="19" r="2.5" /><circle cx="12" cy="11" r="2.5" /><circle cx="19" cy="4" r="2.5" /></>,
  check: <path d="m5 12 5 5L20 7" />,
  x: <path d="M6 6l12 12M18 6 6 18" />,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  calendar: <><rect x="4" y="6" width="16" height="15" rx="2" /><path d="M4 10h16M8 3v5m8-5v5" /></>,
  minimize: <path d="M5 12h14" />,
  maximize: <rect x="5" y="5" width="14" height="14" rx="1.5" />,
  restore: <><rect x="4" y="8" width="12" height="12" rx="1.5" /><path d="M8 8V5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-3" /></>,
  note: <><path d="M5 4h14v11l-5 5H5z" /><path d="M14 20v-5h5" /></>,
  quote: <path d="M7 7h4v4c0 3-2 5-4 6M14 7h4v4c0 3-2 5-4 6" />,
  chevronDown: <path d="m6 9 6 6 6-6" />,
  chevronRight: <path d="m9 6 6 6-6 6" />,
  paperclip: <path d="M21 11.5 12.5 20a5 5 0 0 1-7-7L14 4.5a3.5 3.5 0 0 1 5 5L10.5 18a2 2 0 0 1-3-3L15 7.5" />,
  lock: <><rect x="5" y="11" width="14" height="9" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>,
  tool: <path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.5-.5-.5-2.5z" />,
  eyeClosed: <path d="M3 9c4 8 14 8 18 0M5 12l-2 3m6-1-1 3m7-3 1 3m3-5 2 3" />,
  eye: <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" /></>,
  flag: <path d="M5 21V4h12l-2.5 4L17 12H5" />,
  stop: <><circle cx="12" cy="12" r="9" /><path d="m8.5 12 2.5 2.5 4.5-5" /></>,
  plan: <><path d="M9 6h11M9 12h11M9 18h11" /><path d="m3.5 6 1 1 2-2M3.5 12l1 1 2-2M3.5 18l1 1 2-2" /></>,
  library: <path d="M4 4v16M9 4v16M14 4.5l5 15.5" />,
  wiki: <><circle cx="6" cy="6" r="2.5" /><circle cx="18" cy="8" r="2.5" /><circle cx="10" cy="18" r="2.5" /><path d="M8.4 6.3 15.5 7.7M6.8 8.4l2.4 7.2M16.6 10.1l-5 6" /></>,
  settings: <>
    <path d="M10.5 2h3l.5 2.5 1.6.7 2.2-1.4 2.4 2.4-1.4 2.2.7 1.6 2.5.5v3l-2.5.5-.7 1.6 1.4 2.2-2.4 2.4-2.2-1.4-1.6.7-.5 2.5h-3l-.5-2.5-1.6-.7-2.2 1.4-2.4-2.4 1.4-2.2-.7-1.6-2.5-.5v-3l2.5-.5.7-1.6-1.4-2.2 2.4-2.4 2.2 1.4 1.6-.7z" />
    <circle cx="12" cy="12" r="3" />
  </>,
  shield: <><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z" /><path d="m9 12 2 2 4-4" /></>,
  alert: <><circle cx="12" cy="12" r="9" /><path d="M12 7.5v5.5M12 16.5v.01" /></>,
  undo: <><path d="M9 14 4 9l5-5" /><path d="M4 9h11a5 5 0 0 1 0 10h-3" /></>,
  sidebar: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M9 4v16" /></>,
  panelRight: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M15 4v16" /></>,
}

export function Icon({ name, size = 16, className }: { name: keyof typeof PATHS | string; size?: number; className?: string }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {PATHS[name]}
    </svg>
  )
}

export function Spinner() {
  return <span className="spinner" aria-hidden="true" />
}
