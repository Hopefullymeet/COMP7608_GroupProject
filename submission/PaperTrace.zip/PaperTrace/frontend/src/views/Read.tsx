import { usePreferences } from '../data/preferences'
import { count, useLanguage } from '../i18n'
import { lazy, Suspense, useContext, useEffect, useId, useLayoutEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from 'react'
import { allEvidence, currentTopic, evidenceFor, hasMessages, paperFor, papersOfTopic, sourceStatus, useStore } from '../data/store'
import { QUESTIONS } from '../data/scripts'
import { quoteOffsets } from '../components/quoteRange'
import { EvidencePopover } from '../components/EvidencePopover'
import { Icon, Spinner } from '../components/Icon'
import { useAnswerScroll } from '../components/useAnswerScroll'
import { PaperFolders } from '../components/PaperFolders'
import { useRead, useWorkspace } from '../data/WorkspaceProvider'
import { createPortal } from 'react-dom'
import { Dialog, HeaderActions } from '../components/PageHead'
import { FigurePreview } from '../components/FigurePreview'
import { FigureSearch } from '../components/FigureSearch'
import { PublicationDetails } from '../components/PublicationDetails'
import { AnswerText } from '../components/AnswerText'
import { errorText } from '../api/contract'
import type { ReaderAnswer, Rect, Selection } from '../api/reader'
import type { AnswerSegment, AgentRun, AgentStep, ChatMessage, Paper, Passage } from '../data/types'

const PdfReader = lazy(() => import('./PdfReader'))

type Location = { page: number; rect?: Rect }

function ClaimSources({ ids, sentence, numbers }: { ids: string[]; sentence: number; numbers: Map<string, number> }) {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  const [index, setIndex] = useState(0)
  const active = ids.indexOf(state.activeEvidence?.id ?? '')
  const current = active >= 0 ? active : Math.min(index, ids.length - 1)
  function open(at: number) {
    setIndex(at)
    act.openEvidence(ids[at], '', true)
  }
  return <span className="claim-sources">
    <button className="cite" aria-label={tr('Show source {0} for sentence {1}', numbers.get(ids[current])!, sentence)}
      onClick={() => open(current)}>{numbers.get(ids[current])}</button>
    {ids.length > 1 && <>
      <button className="cite" disabled={!current} title={tr('Previous supporting passage')} aria-label={tr('Previous supporting passage')}
        onClick={() => open(current - 1)}>‹</button>
      <small aria-live="polite">{current + 1}/{ids.length}</small>
      <button className="cite" disabled={current === ids.length - 1} title={tr('Next supporting passage')} aria-label={tr('Next supporting passage')}
        onClick={() => open(current + 1)}>›</button>
    </>}
  </span>
}

function WorkStep({ step }: { step: AgentStep }) {
  const { tr } = useLanguage()
  const activity = step.activity
  const fragments = activity?.passages ?? []
  const papers = [...new Set(fragments.map(p => p.paper))]
  const result = step.detail?.match(/^(\d+) result\(s\)\.(?: ([\s\S]+))?$/)
  const query = activity?.query || result?.[2]
  const target = query || papers.join('、') || activity?.paper
  const outcome = result ? tr('{0} results', result[1]) : step.detail && tr(step.detail)
  const icon = step.title.includes('search') ? 'search' : step.title === 'paper_read' ? 'book' : 'tool'
  const label = <>
    <span className="work-step-icon"><Icon name={icon} size={14} /></span>
    <span className="work-step-copy"><strong>{tr(step.title)}</strong>
      {target && <span className="work-step-target">{target}</span>}
    </span>
  </>
  if (!fragments.length && !step.call && !activity?.paper)
    return <li className="work-step-row">{label}{outcome && <small>{outcome}</small>}</li>
  return <li><details><summary className="work-step-row">{label}<Icon className="work-chevron" name="chevronRight" size={13} /></summary>
    <div className="work-step-evidence">
      {query && activity?.paper && <p>{activity.paper}</p>}
      {outcome && <small>{outcome}</small>}
      {step.call && <code>{step.call}</code>}
      {fragments.map(fragment => <blockquote key={fragment.passage_id}>
        <strong>{papers.length > 1 && fragment.paper + ' · '}
          {fragment.page ? tr('PDF page {0}', fragment.page) : tr('Abstract')}
          {fragment.ordinal != null && ' · ' + tr('Passage {0}', fragment.ordinal + 1)}
        </strong>
        <p>{fragment.excerpt}</p>
      </blockquote>)}
    </div>
  </details></li>
}

function WorkSteps({ run, done }: { run: AgentRun; done: boolean }) {
  const { tr } = useLanguage()
  const prefs = usePreferences()
  const seconds = run.durationSeconds
  const duration = seconds == null ? '' : seconds < 60 ? tr('{0}s elapsed', seconds)
    : tr('{0}m {1}s elapsed', Math.floor(seconds / 60), seconds % 60)
  const status = { running: 'Working…', done: 'Done', partial: 'Partially completed', failed: 'Failed', cancelled: 'Cancelled' }[run.status]
  const visible = run.steps.filter(step => step.title !== 'Evidence review')
  if (!visible.length) return null
  const actions = [...new Set(visible.map(step => tr(step.title)))].join(' · ')
  return <details key={String(done) + prefs.collapse} open={!done || prefs.collapse === 'never'} className="chat-work-steps">
    <summary className="work-heading">
      <Icon name="trace" size={16} /><strong>{tr('Research activity')}</strong>
      <span className="work-status" data-status={run.status}>{tr(status)}</span>
      {duration && <small>{duration}</small>}
      <Icon className="work-chevron" name="chevronRight" size={14} />
    </summary>
    <details className="work-step-group" open={prefs.steps === 'detailed' || !done}>
      <summary><span>{actions}</span><small>{count(tr, visible.length, 'step')}</small>
        <Icon className="work-chevron" name="chevronRight" size={13} /></summary>
      <ul>{visible.map(step => <WorkStep key={step.id} step={step} />)}</ul>
    </details>
  </details>
}

function ReadingCoverage({ segment }: { segment: AnswerSegment }) {
  const { state } = useStore()
  const { tr } = useLanguage()
  const [open, setOpen] = useState(true)
  const scopes = { none: 0, abstract: 1, full_text: 2 }
  const labels = { none: 'Not read', abstract: 'Abstract', full_text: 'Full text' }
  const byPaper = new Map<string, NonNullable<AnswerSegment['readSources']>[number]>()
  for (const source of segment.readSources ?? []) {
    const id = paperFor(state, source.source_version_id)?.paperId ?? source.source_version_id
    const previous = byPaper.get(id)
    if (!previous || scopes[source.read_scope] > scopes[previous.read_scope]) byPaper.set(id, source)
  }
  return <div className="scope-note reading-coverage">
    <button type="button" aria-expanded={open} onClick={() => setOpen(!open)}>
      <Icon name={open ? 'eye' : 'eyeClosed'} size={13} /> {tr('Reading coverage')}
    </button>
    {open && (byPaper.size ? <ul className="scope-sources">{Array.from(byPaper, ([id, source], index) => {
      const paper = paperFor(state, source.source_version_id)
      return <li key={id}>{paper?.alias || paper?.title || tr('Source {0}', index + 1)} · {tr(labels[source.read_scope])}</li>
    })}</ul> : <div>{segment.readSources ? tr('No sources read.') : segment.text}</div>)}
  </div>
}

function AgentMessage({ m, onSource }: { m: ChatMessage; onSource?: (source: Pick<ReaderAnswer, 'source_version_id' | 'page' | 'rect'>) => void }) {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  const runId = m.runId ?? m.wikiTask
  const run = runId ? state.runs[runId] : undefined
  const lastStep = run?.steps[run.steps.length - 1]
  const tools = run?.steps.filter((s) => s.kind === 'tool').length ?? 0
  const papers = papersOfTopic(state, currentTopic(state))
  const citationNumbers = new Map<string, number>()
  for (const segment of m.segments) {
    if (segment.tone === 'scope') continue
    for (const id of segment.evidenceIds ?? (segment.evidenceId ? [segment.evidenceId] : [])) {
      if (!citationNumbers.has(id)) citationNumbers.set(id, citationNumbers.size + 1)
    }
  }
  function renderSegment(s: AnswerSegment, i: number) {
    if (s.tone === 'scope' && !s.readSources?.length && m.figures) return null
    if (s.tone === 'scope') return <ReadingCoverage key={i} segment={s} />
    if (s.evidenceIds?.length) return <span key={i} className="claim">
      {s.text}<ClaimSources ids={[...new Set(s.evidenceIds)]} sentence={i + 1} numbers={citationNumbers} />
    </span>
    if (s.evidenceIds?.length === 0) return <span key={i} className="claim" title={tr('No verified passage was found.')}>
      {s.text}
    </span>
    if (!s.evidenceId) return <span key={i}>{s.text}</span>
    const source = evidenceFor(state, s.evidenceId)
    const status = sourceStatus(state, source.paperId)
    const jump = status === 'available' && papers.includes(source.paperId)
    const anchor = `chat-${m.id}-${i}`
    return (
      <span key={i} className={`claim ${state.activeEvidence?.id === source.id ? 'on' : ''}`}>
        {s.text}
        <button className={`cite ${status !== 'available' ? 'gone' : ''}`} data-ev-anchor={anchor}
          onClick={() => act.openEvidence(source.id, jump ? `read-${source.id}` : anchor, jump)}
          aria-label={tr('Show source {0}{1}', citationNumbers.get(source.id)!, status === 'available' ? '' : ` · ${tr(status)}`)}>{citationNumbers.get(source.id)!}</button>
      </span>
    )
  }

  const blocks: ReactNode[] = []
  let paragraph: ReactNode[] = []
  function endParagraph() {
    if (paragraph.length) blocks.push(<p key={`p-${blocks.length}`}>{paragraph}</p>)
    paragraph = []
  }
  m.segments.forEach((segment, i) => {
    if (!state.mainline || segment.tone === 'scope') {
      endParagraph()
      blocks.push(renderSegment(segment, i))
      return
    }
    if (segment.paragraphStart) endParagraph()
    if (paragraph.length && !/^[\u3400-\u9fff]/u.test(segment.text)) paragraph.push(' ')
    paragraph.push(renderSegment(segment, i))
  })
  endParagraph()
  return (
    <div className="msg agent" data-answer-id={m.id}>
      {!m.done && <div className="msg-who"><span className="working"><Spinner /> {tr(lastStep?.title ?? 'Planning…')}</span></div>}
      {m.wikiTask && state.topics.find(t=>t.id===currentTopic(state))?.wikiTurns?.includes(m.wikiTask) && <small className="wiki-update"><Icon name="wiki" size={13}/>{tr('Wiki updated')}</small>}
      {run && run.steps.length > 0 && <WorkSteps run={run} done={m.done} />}
      {m.figures?.map(f => <FigurePreview key={f.object_id} topic={currentTopic(state)} item={f}
        title={paperFor(state, f.source_version_id).short} open={onSource && (() => onSource(f))} />)}
      {m.segments.length > 0 && (
        <div className="answer">
          {blocks}
          {m.done && m.segments.some(s => s.evidenceIds?.length === 0) &&
            !m.segments.some(s => s.evidenceIds?.length) &&
            <small>{tr('No verified passage was found.')}</small>}
        </div>
      )}
      {m.done && (run || state.mainline?.saveAnswer) && (
        <div className="msg-foot">
          {run && <div className="msg-foot-status">
            <span className="run-chip done">{tr('Done')}</span>
            {run.steps.length > 0 && <span>{count(tr, run.steps.length, 'step')} · {count(tr, tools, 'tool call')}</span>}
          </div>}
          <div className="msg-foot-actions">
            {state.mainline?.saveAnswer && <button className="ghost-btn sm" onClick={() => state.mainline?.saveAnswer?.(m)}>
              <Icon name="note" size={14} /> {tr('Save answer as note')}
            </button>}
            {run && <button className="ghost-btn sm" onClick={() => act.showTrace(true, run.id)}>
              <Icon name="trace" size={14} /> {tr('View trace')}
            </button>}
          </div>
        </div>
      )}
    </div>
  )
}

type Annotation = { id: string; version: string; quote: string; passage?: string; selection?: Selection }

function useAnnotations() {
  const [items, setItems] = useState<Annotation[]>([])
  const input = useRef<HTMLTextAreaElement>(null)
  const [added, setAdded] = useState(0)
  function add(item: Annotation) {
    setItems(old => old.some(a => a.id === item.id) ? old : [...old, item])
    setAdded(n => n + 1)
  }
  function remove(items: Annotation[]) {
    setItems(old => old.filter(a => !items.includes(a)))
  }
  return { items, add, remove, added, input }
}
type Annotations = ReturnType<typeof useAnnotations>
type AskRegion = (annotation: Annotation, question: string) => Promise<boolean>

function Chat({ controls, selections = [], onSource, annotations, askRegion, blocked }: {
  annotations: Annotations; askRegion?: AskRegion; blocked?: string
  controls: ReactNode; selections?: ReaderAnswer[]; onSource?: (answer: Pick<ReaderAnswer, 'source_version_id' | 'page' | 'rect'>) => void
}) {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  const actions = useContext(HeaderActions)
  const prefs = usePreferences()
  const [queued,setQueued] = useState<{session:string;question:string}>()
  const [text, setText] = useState('')
  const [findingFigures, setFindingFigures] = useState(false)
  const session = state.sessions.find((s) => s.id === state.activeSessionId)
  const messages = state.messages.filter((m) => m.sessionId === session?.id)
  const asked = new Set(messages.filter((m) => m.role === 'user').map((m) => m.segments[0]?.text))
  const papers = papersOfTopic(state, currentTopic(state))
  const readable = papers.filter((id) => paperFor(state, id).stored !== 'metadata')
  const canAsk = !state.mainline || readable.length > 0
  const hasComposer = state.mainline ? readable.length > 0 : papers.length > 0
  const composerDock = useRef<HTMLDivElement>(null)
  useLayoutEffect(() => {
    const field = annotations.input.current
    if (!field) return
    function fit() {
      if (!field || !field.clientWidth) return
      field.style.height = 'auto'
      field.style.height = field.scrollHeight + 'px'
    }
    fit()
    let width = field.clientWidth
    const observer = new ResizeObserver(() => {
      if (field.clientWidth !== width) {
        width = field.clientWidth
        fit()
      }
    })
    observer.observe(field)
    return () => observer.disconnect()
  }, [text, hasComposer, annotations.input])
  useLayoutEffect(() => {
    const dock = composerDock.current
    const chat = dock?.parentElement
    if (!dock || !chat) return
    const measure = () => chat.style.setProperty('--dock-height', dock.offsetHeight + 'px')
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(dock)
    return () => {
      observer.disconnect()
      chat.style.removeProperty('--dock-height')
    }
  }, [hasComposer])

  const last = messages[messages.length - 1]
  const agent = last?.role === 'agent' ? last : undefined
  const turn = agent?.wikiTask ?? agent?.runId ?? agent?.id
  const scroll = useAnswerScroll(session?.id, agent && !agent.done ? turn : last?.role === 'user' && last.id.startsWith('user:') ? last.id.slice(5) : undefined,
    agent?.done ? turn : undefined, agent?.id, agent?.done ? '' : agent?.segments.map(s => s.text).join('') ?? '')

  const turns = [
    ...messages.filter(m => m.role === 'user').map(m => ({ id: m.id, label: m.segments[0]?.text ?? '' })),
    ...selections.map(a => ({ id: 'selection:' + a.id, label: a.question })),
  ]
  const [visibleTurn, setVisibleTurn] = useState('')
  const opened = useRef<string>()
  function jumpToTurn(id: string) {
    const panel = scroll.panel.current
    const target = panel?.querySelector<HTMLElement>('[data-turn-id="' + CSS.escape(id) + '"]')
    if (!target || !panel || !scroll.space.current) return
    const inset = parseFloat(getComputedStyle(panel).paddingTop) || 0
    const top = target.getBoundingClientRect().top - panel.getBoundingClientRect().top + panel.scrollTop - inset
    const spacer = scroll.space.current
    spacer.style.height = Math.ceil(Math.max(0, top + panel.clientHeight - panel.scrollHeight + spacer.offsetHeight)) + 'px'
    panel.scrollTop = top
    setVisibleTurn(id)
  }
  const latestTurn = turns.at(-1)?.id
  useLayoutEffect(() => {
    if (!latestTurn || !session || opened.current === session.id) return
    opened.current = session.id
    if (!state.qaRunning) jumpToTurn(latestTurn)
  }, [session?.id, latestTurn, state.qaRunning])
  function trackTurn() {
    scroll.onScroll()
    const panel = scroll.panel.current
    if (!panel) return
    const edge = panel.getBoundingClientRect().top + parseFloat(getComputedStyle(panel).paddingTop) + 2
    const nodes = Array.from(panel.querySelectorAll<HTMLElement>('[data-turn-id]'))
    setVisibleTurn((nodes.reverse().find(node => node.getBoundingClientRect().top <= edge) ?? nodes.at(-1))?.dataset.turnId ?? '')
  }
  const send = async (t: string, fromComposer = false) => {
    if (!t.trim() || state.qaRunning || !canAsk) return
    const attached = fromComposer ? annotations.items : []
    if (fromComposer && blocked) return
    const region = attached.find(a => a.selection?.medium === 'image') ??
      (attached.length === 1 && attached[0].selection ? attached[0] : undefined)
    const quotes = attached.filter(a => a !== region).map(a => paperFor(state, a.version).short + ' · “' + a.quote + '”')
    const question = [t.trim(), ...quotes].join('\n\n')
    if (region && askRegion) {
      if (!await askRegion(region, question)) return
    } else {
      const first = attached.find(a => a.passage)
      const { requestsFigure } = await import('../visual/retrieve')
      setFindingFigures(requestsFigure(question))
      try {
        if (!await act.ask(question, first && { source_version_id: first.version, passage_id: first.passage!, quote: first.quote })) return
      } finally { setFindingFigures(false) }
    }
    annotations.remove(attached)
    if (fromComposer) setText((current) => current === t ? '' : current)
  }

  const queuedRef = useRef(queued)
  queuedRef.current = queued
  useEffect(() => {
    if (!queued || queuedRef.current !== queued) return
    if (queued.session !== session?.id) { setQueued(undefined); return }
    if (state.qaRunning || blocked || !canAsk) return
    queuedRef.current = undefined
    setQueued(undefined)
    void act.ask(queued.question).then(ok => { if (!ok) setText(current => current || queued.question) })
  }, [queued, session?.id, state.qaRunning, blocked, canAsk, act])
  const canQueue = prefs.busy === 'queue' && !annotations.items.length && !queued && !!session
  function submit() {
    if (state.qaRunning && canQueue && session && text.trim()) {
      setQueued({session:session.id, question:text.trim()}); setText(''); return
    }
    void send(text,true)
  }

  const suggestions = (state.mainline
    ? state.mainline.demo ? [{ id: 'pubmedqa', text: 'What context does PubMedQA provide to the model?', requires: undefined },{id:'limits',text:'What does the abstract establish about the conclusions?',requires:undefined}] : []
    : QUESTIONS).filter((q) => !asked.has(q.text))

  return (
    <section className="chat" aria-label={tr('Conversation')}>
      {actions && createPortal(<>
        {messages.length > 0 && <button className="icon-btn sm" title={tr('New session')} aria-label={tr('New session')} onClick={() => act.newSession(currentTopic(state))}><Icon name="plus" size={15} /></button>}
        {controls}
      </>, actions)}
      <div className="chat-viewport">
      {turns.length > 0 && <nav className="turn-rail" aria-label={tr('Conversation turns')}>
        {turns.map(t => <button key={t.id} title={t.label} aria-label={t.label}
          aria-current={visibleTurn === t.id ? 'location' : undefined} onClick={() => jumpToTurn(t.id)} />)}
      </nav>}
      <div className="chat-scroll" ref={scroll.panel} onScroll={trackTurn}>
        {messages.length === 0 && selections.length === 0 && (
          <div className="chat-empty">
            <h2>{tr('Start a fresh reading question')}</h2>
            <p>{tr(state.mainline?.demo || !state.mainline ? 'Explore dataset size and question collection, then compare evaluation results. Papers are shared across this topic; this conversation starts empty.' : 'Ask about a paper or select a passage to use it in your question.')}</p>
          </div>
        )}
        {messages.map((m) =>
          m.role === 'user'
            ? <div key={m.id} data-turn-id={m.id} className="msg user"><p>{m.segments[0]?.text}</p></div>
            : prefs.collapse === 'finished' && prefs.replies === 'latest' && m.done && messages.slice(messages.indexOf(m)+1).some(next=>next.role==='agent' && next.done)
              ? <details key={m.id}><summary>{tr('Earlier answer')}</summary><AgentMessage m={m} onSource={onSource}/></details>
              : <AgentMessage key={m.id} m={m} onSource={onSource} />,
        )}
        {selections.map((answer) => <div key={answer.id}>
          <div data-turn-id={'selection:' + answer.id} className="msg user"><p>{answer.question}</p></div>
          <div className="msg agent">
            <AnswerText text={answer.answer} />
            <button className="link-btn" onClick={() => onSource?.(answer)}>
              {paperFor(state, answer.source_version_id)?.short} · {tr('PDF page {0}', answer.page)}
            </button>
          </div>
        </div>)}
        <div ref={scroll.space} aria-hidden="true" style={{ flexShrink: 0 }} />
      </div>

      </div>
      {hasComposer && <div className="chat-bottom" ref={composerDock}>
        {suggestions.length > 0 && (
          <div className="suggest-row">
            {suggestions.map((q) => {
              const blocked = state.mainline ? null : !papers.includes('qasper') ? 'qasper' : q.requires && !papers.includes(q.requires) ? q.requires : null
              return (
                <button key={q.id} className="chip-btn" disabled={!!blocked || state.qaRunning || !canAsk} onClick={() => void send(q.text)}
                  title={blocked ? tr('Add {0} to the topic first', paperFor(state, blocked).short) : undefined}>
                  {tr(q.text)}{blocked && <small>{' '}{tr('· needs')}{' '}{paperFor(state, blocked).short}</small>}
                </button>
              )
            })}
          </div>
        )}
        <div className="composer">
          {annotations.items.length > 0 && <div className="chat-annotations">
            <button type="button" className="annotation-count"><Icon name="message" size={14} />
              {tr(annotations.items.length === 1 ? '{0} annotation' : '{0} annotations', annotations.items.length)}</button>
            <div className="annotation-details">
              {annotations.items.map(a => <div className="annotation-row" key={a.id}>
                <div><strong>{paperFor(state, a.version).short}{a.selection && ' · ' + tr('PDF page {0}', a.selection.page)}</strong>
                  <p>{a.quote || tr('Selected region')}</p></div>
                <button type="button" className="icon-btn sm" aria-label={tr('Remove annotation')} onClick={() => annotations.remove([a])}><Icon name="x" size={14} /></button>
              </div>)}
            </div>
          </div>}
          {queued && <p role="status">{tr('Queued question')} · {queued.question} <button onClick={()=>setQueued(undefined)}>{tr('Cancel')}</button></p>}
          {findingFigures && <div role="status" className="working"><Spinner /> {tr('Searching paper figures…')}</div>}
          {blocked && <p className="fine">{blocked}</p>}
          <textarea ref={annotations.input} value={text} rows={1} placeholder={messages.length ? tr('Ask a follow-up…') : tr('Ask about these papers…')} aria-label={tr('Ask a follow-up')}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing && (prefs.send === 'enter' || e.metaKey || e.ctrlKey)) { e.preventDefault(); submit() } }} />
          <div className="composer-bar">
            <span className="grow" />
            <button className="send" disabled={(state.qaRunning && !canQueue) || !canAsk || !!blocked || !text.trim()} onClick={submit} aria-label={tr('Send')}><Icon name="arrowUp" size={16} /></button>
          </div>
        </div>
      </div>}
    </section>
  )
}

function PassageText({ p, highlight }: { p: Passage; highlight: Set<string> }) {
  const { state, act } = useStore()
  const anchors = allEvidence(state)
    .filter((e) => e.passageId === p.id && highlight.has(e.id))
    .map((e) => ({ e, at: p.text.indexOf(e.quote) }))
    .filter((x) => x.at >= 0)
    .sort((a, b) => a.at - b.at)

  const out: ReactNode[] = []
  let cursor = 0
  anchors.forEach(({ e, at }) => {
    if (at < cursor) return
    out.push(p.text.slice(cursor, at))
    const active = state.activeEvidence?.id === e.id
    out.push(
      <mark key={e.id} data-ev-anchor={`read-${e.id}`} className={active ? 'on' : ''}
        onClick={() => act.openEvidence(e.id, `read-${e.id}`, false)}>{e.quote}</mark>,
    )
    cursor = at + e.quote.length
  })
  out.push(p.text.slice(cursor))
  return <>{out} </>
}

type PdfActions = {
  location?: { version: string } & Location
  open: (version: string, page: number, rect?: Rect) => void
  ask: (version: string, picked: Selection) => void
  find: () => void
}

function PaperInsights({ paper, mode, onOpen }: { paper: Paper; mode: 'scan' | 'analysis'; onOpen: (version: string, page: number) => void }) {
  const { tr } = useLanguage()
  const { state } = useStore()
  const { demo } = useWorkspace()
  const topic_id = currentTopic(state)
  const [direction, setDirection] = useState<'outgoing' | 'incoming'>('outgoing')
  const refs = useRead('literature.refs', { topic_id, source_version_id: paper.id, direction }, mode === 'analysis')
  const catalog = useRead('library.catalog', {}, mode === 'scan')
  const entry = catalog?.papers.find((item) => item.source_versions.some((version) => version.source_version_id === paper.id))
  return <div className="reader-scroll scroll pt-paper-insights">
    <article className="paper">
      <h1>{paper.title}</h1>
      {mode === 'scan' ? <>
        {!!(entry?.authors.length || paper.authors.length) && <p className="paper-authors">{(entry?.authors.length ? entry.authors : paper.authors).join(' · ')}</p>}
        {paper.venue && <p>{paper.venue} {paper.year || ''}</p>}
        {entry?.identity && <p className="fine">{entry.identity}</p>}
        {entry && !demo && <PublicationDetails paper={entry.paper_id} topic={topic_id} />}
        <button className="link-btn" onClick={() => onOpen(paper.id, 1)}>{tr('Read paper')}</button>
      </> : <>
        <div className="lib-tools">
          <button className="ghost-btn" aria-pressed={direction === 'outgoing'} onClick={() => setDirection('outgoing')}>{tr('References')}</button>
          <button className="ghost-btn" aria-pressed={direction === 'incoming'} onClick={() => setDirection('incoming')}>{tr('Cited by')}</button>
        </div>
        {!refs && <p role="status">{tr('Loading references…')}</p>}
        {!!refs?.pending_versions.length && <p>{tr('Reference indexing is pending.')}</p>}
        {refs && !refs.items.length && <p>{tr('No indexed references found.')}</p>}
        {!!refs?.items.length && <ul>{refs.items.map((ref) => {
          const linked = direction === 'outgoing' ? ref.target_version_id : ref.citing_version_id
          return <li key={ref.citing_version_id + ':' + ref.key}>
            {linked ? <button className="link-btn" onClick={() => onOpen(linked, 1)}>
              {direction === 'outgoing' ? ref.target_title || ref.title : ref.citing_title}
            </button> : ref.title || ref.text}
            {ref.mentions.filter((item) => item.page > 0).slice(0, 3).map((item, index) =>
              <button className="link-btn" key={index} onClick={() => onOpen(ref.citing_version_id, item.page)}>
                {tr('PDF page {0}', item.page)}
              </button>)}
          </li>
        })}</ul>}
      </>}
    </article>
  </div>
}

type PaperChoice = { paper: Paper; label: string; version?: string }

function PaperDirectory({ choices, selected, topicId, onSelect }: {
  choices: PaperChoice[]; selected: string; topicId: string; onSelect: (id: string) => void
}) {
  const { tr } = useLanguage()
  const workspace = useWorkspace()
  const root = useRef<HTMLDivElement>(null)
  const toggle = useRef<HTMLButtonElement>(null)
  const id = useId()
  const [open, setOpen] = useState(false)
  const [folder, setFolder] = useState('')
  const folders = useRead('library.folders', { topic_id: topicId }, open && !!topicId)
  const active = choices.find(c => c.paper.id === selected)?.paper.paperId
  const [editing, edit] = useState<Paper>()
  const [alias, setAlias] = useState('')
  const [saving, setSaving] = useState(false)
  const [problem, setProblem] = useState('')

  useEffect(() => {
    if (!open || editing) return
    function outside(event: PointerEvent) {
      if (event.target instanceof Node && !root.current?.contains(event.target)) setOpen(false)
    }
    window.addEventListener('pointerdown', outside)
    return () => window.removeEventListener('pointerdown', outside)
  }, [open, editing])

  function close() {
    setOpen(false)
    toggle.current?.focus({ preventScroll: true })
  }

  return <>
    <div className="pt-paper-directory" ref={root} onKeyDown={(event) => {
      if (!open || event.key !== 'Escape') return
      event.stopPropagation()
      close()
    }}>
      <button ref={toggle} className="pt-round" type="button" aria-expanded={open} aria-controls={open ? id : undefined}
        title={tr('Paper list')} aria-label={tr('Paper list')} onClick={() => setOpen((value) => !value)}>
        <Icon name="paperList" size={17} />
      </button>
      {open && <nav id={id} className="pt-paper-list" aria-label={tr('Papers in this reader')}>
        <PaperFolders topic={topicId} folders={folders} filter={folder} onFilter={setFolder} papers={active ? [active] : []} />
        {choices.filter(c => !folder || (folders && (folders.assignments[c.paper.paperId ?? ''] || '-') === folder)).map(({ paper, label, version }) => <div className="pt-paper-row" key={paper.id}>
          <button className="pt-paper-open" type="button" title={paper.alias ? `${paper.alias} · ${paper.title}` : paper.title}
            aria-pressed={selected === paper.id} onClick={() => { onSelect(paper.id); close() }}>
            <Icon name="file" size={14} />
            <span>{paper.alias || label}</span>
            {version && <small>{version}</small>}
          </button>
          {paper.paperId && paper.pdfAvailable && <button type="button" className="icon-btn pt-paper-alias"
            title={tr('Edit paper alias')} aria-label={tr('Edit alias for {0}', paper.alias || label)}
            onClick={() => { setAlias(paper.alias ?? ''); setProblem(''); edit(paper) }}>
            <Icon name="edit" size={14} />
          </button>}
        </div>)}
      </nav>}
    </div>
    {editing && <Dialog title={tr('Edit paper alias')} onClose={() => { if (!saving) edit(undefined) }}>
      <p className="dialog-text">{editing.title}</p>
      <form onSubmit={async (event) => {
        event.preventDefault()
        if (!editing.paperId || saving) return
        setSaving(true)
        setProblem('')
        try {
          await workspace.write('library.set_alias', { topic_id: topicId, paper_id: editing.paperId, alias: alias.trim() })
          edit(undefined)
        } catch (error) {
          setProblem(errorText(error))
        } finally {
          setSaving(false)
        }
      }}>
        <label className="rename-field">{tr('Alias')}
          <input autoFocus placeholder={tr('Use original title')} value={alias} maxLength={80}
            onChange={(event) => setAlias(event.currentTarget.value)} />
        </label>
        {problem && <p role="alert">{tr(problem)}</p>}
        <div className="dialog-actions">
          <button className="ghost-btn" type="button" disabled={saving} onClick={() => edit(undefined)}>{tr('Cancel')}</button>
          <button className="primary" disabled={saving}>{tr('Save')}</button>
        </div>
      </form>
    </Dialog>}
  </>
}

function Reader({ pdf }: { pdf?: PdfActions }) {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  const papers = papersOfTopic(state, currentTopic(state)).map((id) => paperFor(state, id))
  const historical = state.mainline && state.activeEvidence && paperFor(state, state.readerPaperId)
  const paper = historical || (papers.find((p) => p.id === state.readerPaperId) ?? papers[0])

  const [mode, setMode] = useState<'scan' | 'reading' | 'analysis'>('reading')
  useEffect(() => { setMode('reading') }, [paper?.id, state.activeEvidence?.id, pdf?.location])
  const scrollTimer=useRef<ReturnType<typeof setTimeout>>()
  useEffect(()=>()=>clearTimeout(scrollTimer.current),[paper?.id,state.activeSessionId])
  const active = state.activeEvidence
  const evidence = active && evidenceFor(state, active.id)
  const [missing, setMissing] = useState<typeof active>()
  const citation = useMemo(() => active && evidence ? {
    anchor: active.anchor, quote: evidence.quote, passage: paper?.passages.find(p => p.id === evidence.passageId)?.text, onMissing: () => setMissing(active),
  } : undefined, [active, evidence, paper?.passages])
  if (!paper) return <div className="empty-state"><h2>{tr('No papers in this topic')}</h2><button className="primary" onClick={() => act.openTopic(currentTopic(state), 'discover')}>{tr('Find papers')}</button></div>

  const choices = (papers.some((p) => p.id === paper.id) ? papers : [paper, ...papers]).map((p) => {
    const version = p.short === `${p.title} · ${p.id}` ? p.id.slice(0, 8) : undefined
    return { paper: p, label: version ? p.title : p.short, version }
  })
  const withPdf = Boolean(pdf && paper.pdfAvailable && (!active || (active.pdfPage && active !== missing)))
  const location = pdf?.location?.version === paper.id ? pdf.location : undefined
  const evidencePage = state.activeEvidence?.pdfPage
  const currentLocation = state.activeEvidence
    ? { page: evidencePage && evidencePage > 0 ? evidencePage : 1, rect: state.activeEvidence.region }
    : location
  const used = new Set<string>()
  state.messages.filter((m) => m.sessionId === state.activeSessionId)
    .forEach((m) => m.segments.forEach((s) => s.evidenceId && used.add(s.evidenceId)))
  state.cited.forEach((id) => used.add(id))
  state.noted.forEach((id) => used.add(id))
  if (state.activeEvidence) used.add(state.activeEvidence.id)

  return (
    <section className={pdf ? 'reader reader--library' : 'reader'} aria-label={tr('Paper')}>
      {pdf ? <PaperDirectory key={currentTopic(state)} topicId={currentTopic(state)} choices={choices} selected={paper.id}
        onSelect={(id) => {
          if (id === paper.id) return
          act.setReader(id)
          setMode('reading')
        }} /> : <div className="reader-bar">
        <div className="paper-tabs" role="group" aria-label={tr('Papers in this reader')}>
          {choices.map(({ paper: p, label, version }) => (
            <button key={p.id} className={p.id === paper.id ? 'on' : ''} aria-pressed={p.id === paper.id}
              title={p.short} onClick={() => act.setReader(p.id)}>
              <span className="paper-tab-label">{label}</span>
              {version && <small className="paper-tab-version">{version}</small>}
            </button>
          ))}
        </div>
        <select className="paper-picker" aria-label={tr('Paper in reader')} title={paper.short}
          value={paper.id} onChange={(event) => act.setReader(event.target.value)}>
          {choices.map(({ paper: p, label, version }) => (
            <option key={p.id} value={p.id}>{version ? `${version} · ${label}` : label}</option>
          ))}
        </select>
      </div>}
      <div className="pt-reading-content">
      {pdf && withPdf ? <><Suspense fallback={<p className="pt-pdf-loading" role="status">{tr('Opening PDF…')}</p>}>
        <PdfReader key={paper.id} topic={currentTopic(state)} version={paper.id} page={currentLocation?.page}
          session={state.activeSessionId ?? undefined} resume={!location}
          target={currentLocation?.rect} citation={citation}
          onAsk={(selection) => pdf.ask(paper.id, selection)} onFind={pdf.find} onPaperInfo={setMode}
          onWiki={() => act.navigate({ view: 'wiki', topicId: currentTopic(state) })} />
      </Suspense>
        {mode !== 'reading' && <Dialog title={tr(mode === 'scan' ? 'Paper details' : 'Paper references')} onClose={() => setMode('reading')}>
          <PaperInsights key={paper.id} paper={paper} mode={mode} onOpen={(version, page) => {
            pdf.open(version, page)
            setMode('reading')
          }} />
        </Dialog>}
      </> :
      <div className="reader-scroll scroll" onScroll={e=>{
        if(!state.mainline?.bookmark || state.activeEvidence)return
        const scroller=e.currentTarget
        clearTimeout(scrollTimer.current)
        scrollTimer.current=setTimeout(()=>{
          const top=scroller.getBoundingClientRect().top
          const p=Array.from(scroller.querySelectorAll<HTMLElement>('[data-passage-id]')).find(p=>p.getBoundingClientRect().bottom>top)
          if(p?.dataset.passageId)state.mainline?.bookmark?.(paper.id,p.dataset.passageId)
        },400)
      }}>
        <article className="paper">
          <p className="paper-venue">{paper.venue} {paper.year || ''}{paper.externalId && <> · {paper.externalId}</>}</p>
          <h1>{paper.title}</h1>
          <p className="paper-authors">{paper.authors.join(' · ')}</p>
          <div className="paper-meta">
            <span><Icon name="file" size={13} /> {paper.stored === 'full-text' ? tr('Full text')
              : paper.stored === 'excerpt' ? tr('Selected excerpts') : paper.stored === 'abstract' ? (state.mainline ? tr('Abstract stored') : tr('Abstract stored · PDF p. 1')) : tr('Metadata only')}</span>
            {paper.venueSource && <span>{tr('Venue from')}{' '}{paper.venueSource}</span>}
            {state.mainline && <span>{tr('Source version ·')}{' '}{paper.id}</span>}
          </div>

          {paper.stored !== 'metadata' ? (
            <>
              {paper.stored === 'excerpt' ? paper.passages.map((p) => (
                <section key={p.id}>
                  <h2>{p.section}{' '}{tr('· PDF p.')}{' '}{p.page}</h2>
                  <p className="abstract"><PassageText p={p} highlight={used} /></p>
                </section>
              )) : <>
                <h2>{paper.stored === 'abstract' ? tr('Abstract') : tr('Full text')}</h2>
                {state.mainline ? paper.passages.map((p) => {
                  const active = state.activeEvidence && evidenceFor(state, state.activeEvidence.id)?.passageId === p.id
                  const quote=active&&state.activeEvidence?evidenceFor(state,state.activeEvidence.id)?.quote:''
                  const match = quote ? quoteOffsets(p.text, quote) : undefined
                  return <section key={p.id} data-passage-id={p.id}>{p.page>0&&<h3>{p.section}{' '}{tr('· p.')}{' '}{p.page}</h3>}<p onMouseUp={()=>{const text=window.getSelection()?.toString().trim();if(text&&p.text.includes(text))state.mainline?.selectQuote?.(paper.id,p.id,text)}} className="abstract">
                    {match ? <>{p.text.slice(0, match[0])}<mark className="on" data-ev-anchor={state.activeEvidence?.anchor}>{p.text.slice(...match)}</mark>{p.text.slice(match[1])}</> : p.text}
                  </p><button className="link-btn quiet" onClick={()=>state.mainline?.bookmark?.(paper.id,p.id)}>{tr('Bookmark passage')}</button></section>
                }) : <p className="abstract">{paper.passages.map((p) => <PassageText key={p.id} p={p} highlight={used} />)}</p>}
              </>}
              {!state.mainline && paper.stored !== 'full-text' && <div className="fulltext-note">
                <Icon name="lock" size={15} />
                <div>
                  <strong>{tr('Full text not loaded')}</strong>
                  <p>{tr('This prototype shows the available passages. The full app will show the parsed paper with page mapping.')}</p>
                </div>
              </div>}
            </>
          ) : (
            <div className="fulltext-note">
              <Icon name="alert" size={15} />
              <div><strong>{tr('No text stored')}</strong><p>{tr('This paper was added from search metadata. Import its PDF to read it here.')}</p></div>
            </div>
          )}
        </article>
      </div>}
      </div>
    </section>
  )
}

function ReadingSplit({ selections, onSource, reader, annotations, askRegion, blocked }: {
  annotations: Annotations; askRegion?: AskRegion; blocked?: string
  selections?: ReaderAnswer[]
  onSource?: (answer: Pick<ReaderAnswer, 'source_version_id' | 'page' | 'rect'>) => void
  reader: ReactNode
}) {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  const layout = useRef<HTMLDivElement>(null)
  const drag = useRef<{ id: number; offset: number }>()
  const chatId = useId()
  const paperId = useId()
  const [collapsed, setCollapsed] = useState<'chat' | 'paper' | undefined>(() => {
    const session = state.sessions.find(s => s.id === state.activeSessionId)
    return session && (session.hasTurns || hasMessages(state, session.id)) || state.activeEvidence ? undefined : 'paper'
  })
  const [readerOpened, setReaderOpened] = useState(collapsed !== 'paper')
  useEffect(() => {
    if (collapsed !== 'paper') setReaderOpened(true)
  }, [collapsed])
  const [dragging, setDragging] = useState(false)
  const [width, setWidth] = useState(0)
  const [preferredShare, setPreferredShare] = useState<number>()
  const minShare = width ? Math.min(240 / width, .4) : .4
  const maxShare = .6
  const share = Math.max(minShare, Math.min(maxShare, preferredShare ?? .5))

  useEffect(() => {
    if (!layout.current) return
    const observer = new ResizeObserver(([entry]) => setWidth(entry.contentRect.width))
    observer.observe(layout.current)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (state.activeEvidence?.scroll) setCollapsed((current) => current === 'paper' ? undefined : current)
  }, [state.activeEvidence])

  useEffect(() => {
    if (!annotations.added) return
    setCollapsed(undefined)
    const frame = requestAnimationFrame(() => annotations.input.current?.focus())
    return () => cancelAnimationFrame(frame)
  }, [annotations.added, annotations.input])

  const paperLabel = tr(collapsed === 'paper' ? 'Show paper pane' : 'Hide paper pane')
  const chatLabel = tr(collapsed === 'chat' ? 'Show conversation pane' : 'Hide conversation pane')

  return <div ref={layout} className={`read${dragging ? ' read--resizing' : ''}`}
    data-collapsed={collapsed} style={{ '--read-chat-width': `${share * 100}%` } as CSSProperties}>
    <EvidencePopover onAsk={(id) => {
      const evidence = evidenceFor(state, id)
      annotations.add({ id, version: evidence.paperId, quote: evidence.quote, passage: evidence.passageId })
      act.closeEvidence()
    }} />
    <div className="read-chat-pane" id={chatId} hidden={collapsed === 'chat'}>
      <Chat annotations={annotations} askRegion={askRegion} blocked={blocked} selections={selections} onSource={onSource && ((answer) => {
        if (collapsed === 'paper') setCollapsed(undefined)
        onSource(answer)
      })} controls={<>
        {collapsed !== 'paper' && <button className="icon-btn sm" type="button"
          title={chatLabel} aria-label={chatLabel} aria-controls={chatId} aria-expanded={collapsed !== 'chat'}
          onClick={() => setCollapsed(current => current === 'chat' ? undefined : 'chat')}>
          <Icon name="sidebar" size={16} />
        </button>}
        <button className="icon-btn sm" type="button" title={paperLabel} aria-label={paperLabel}
          aria-controls={paperId} aria-expanded={collapsed !== 'paper'}
          onClick={() => {
            if (collapsed === 'paper') {
              setCollapsed(undefined)
            } else {
              act.closeEvidence()
              setCollapsed('paper')
            }
          }}>
          <Icon name="panelRight" size={16} />
        </button>
      </>} />
    </div>
    {!collapsed && <div className="read-divider" role="separator" tabIndex={0} aria-orientation="vertical"
      aria-label={tr('Resize paper pane')} title={tr('Drag to resize the paper pane')}
      aria-controls={paperId} aria-valuemin={Math.round((1 - maxShare) * 100)}
      aria-valuemax={Math.round((1 - minShare) * 100)} aria-valuenow={Math.round((1 - share) * 100)}
      onPointerDown={(event) => {
        if (!event.isPrimary || event.button !== 0) return
        const { left, width: handleWidth } = event.currentTarget.getBoundingClientRect()
        drag.current = { id: event.pointerId, offset: event.clientX - left - handleWidth / 2 }
        event.currentTarget.setPointerCapture(event.pointerId)
        setDragging(true)
      }}
      onPointerMove={(event) => {
        if (drag.current?.id !== event.pointerId || !layout.current) return
        const bounds = layout.current.getBoundingClientRect()
        const next = (event.clientX - bounds.left - drag.current.offset) / bounds.width
        setPreferredShare(Math.max(minShare, Math.min(maxShare, next)))
      }}
      onLostPointerCapture={() => { drag.current = undefined; setDragging(false) }}
      onDoubleClick={() => setPreferredShare(undefined)}
      onKeyDown={(event) => {
        let next: number
        switch (event.key) {
          case 'ArrowLeft': next = share - .03; break
          case 'ArrowRight': next = share + .03; break
          case 'Home': next = maxShare; break
          case 'End': next = minShare; break
          default: return
        }
        event.preventDefault()
        setPreferredShare(Math.max(minShare, Math.min(maxShare, next)))
      }} />}
    <div className="read-paper-pane" id={paperId} hidden={collapsed === 'paper'}>{(readerOpened || collapsed !== 'paper') && reader}</div>
  </div>
}

function LiveReading({ topic, session, annotations }: { topic: string; session: string; annotations: Annotations }) {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  const workspace = useWorkspace()
  const [location, setLocation] = useState<PdfActions['location']>()
  const [finding, setFinding] = useState(false)
  const answers = useRead('reader.answers', { topic_id: topic, session_id: session })?.items.slice().reverse()
  const vision = useRead('visual.capabilities', {}, annotations.items.some(a => a.selection?.medium === 'image'))
  const papers = papersOfTopic(state, topic).map((id) => paperFor(state, id)).filter((paper) => paper.pdfAvailable)
  const names = Object.fromEntries(papers.map((paper) => [paper.id, paper.short]))

  useEffect(() => {
    if (state.activeEvidence?.id) setLocation(undefined)
  }, [state.activeEvidence?.id])

  function open(version: string, page: number, rect?: Rect) {
    if (state.readerPaperId !== version || state.activeEvidence) act.setReader(version)
    setLocation({ version, page, rect })
  }

  function ask(version: string, selection: Selection) {
    annotations.add({ id: JSON.stringify([version, selection.page, selection.rect]), version, quote: selection.quote, selection })
  }

  return <>
    <ReadingSplit annotations={annotations}
      blocked={annotations.items.filter(a => a.selection?.medium === 'image').length > 1 ? tr('Send one image region at a time.') :
        annotations.items.some(a => a.selection?.medium === 'image') && !vision?.vision ? tr('Configure a local vision model to ask about images.') : undefined}
      askRegion={async (a, question) => {
        const { page, rect, rects, medium } = a.selection!
        let accepted = false
        await workspace.prepare({ topic_id: topic, session_id: session, kind: 'reader_question',
          input: { source_version_id: a.version, question, page, rect, rects, medium } }, () => { accepted = true })
        return accepted
      }} selections={answers} onSource={(answer) => open(answer.source_version_id, answer.page, answer.rect)}
      reader={<Reader pdf={{ location, open, ask, find: () => setFinding(true) }} />} />
    {finding && <FigureSearch topic={topic} versions={papers.map((paper) => paper.id)} names={names}
      onOpen={(figure) => open(figure.source_version_id, figure.page, figure.rect)}
      onAsk={(figure) => {
        open(figure.source_version_id, figure.page, figure.rect)
        ask(figure.source_version_id, { page: figure.page, rect: figure.rect, rects: [figure.rect], quote: figure.caption, medium: 'image' })
      }} onClose={() => setFinding(false)} />}
  </>
}

export function Read() {
  const { tr } = useLanguage()
  const { state, act } = useStore()
  if (!state.activeSessionId) {
    return <div className="empty-state"><Icon name="message" size={22} /><h2>{tr('No sessions yet')}</h2><p>{tr('Create a session to start asking about the papers in this topic.')}</p><button className="primary" onClick={() => act.newSession(currentTopic(state))}><Icon name="plus" size={15} />{' '}{tr('New session')}</button></div>
  }
  return <ReadingSession key={state.activeSessionId} session={state.activeSessionId} />
}

function ReadingSession({ session }: { session: string }) {
  const { state } = useStore()
  const annotations = useAnnotations()
  if (state.mainline && !state.mainline.demo) {
    return <LiveReading annotations={annotations} topic={currentTopic(state)} session={session} />
  }
  return <ReadingSplit annotations={annotations} reader={<Reader />} />
}
