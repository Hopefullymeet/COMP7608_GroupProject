#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
if [[ "$(uname -s)" != Darwin ]]; then echo "Run this launcher on macOS." >&2; exit 1; fi
if [[ "$(sysctl -in sysctl.proc_translated 2>/dev/null || true)" == 1 ]]; then
  exec arch -arm64 /bin/bash ./Build-macOS.command "$@"
fi
if ! xcrun --find clang >/dev/null 2>&1 || ! xcrun --sdk macosx --show-sdk-path >/dev/null 2>&1; then
  xcode-select --install || true
  echo "Finish Apple's Command Line Tools installation and rerun this launcher. If already installed, select the active developer directory with xcode-select --switch." >&2
  exit 1
fi
tmpdir="$(mktemp -d)"
trap 'rm -f "$tmpdir/install.sh"; rmdir "$tmpdir"' EXIT
install_tool() {
  curl --fail --show-error --silent --location --proto '=https' "$1" -o "$tmpdir/install.sh"
  shift
  sh "$tmpdir/install.sh" "$@"
}
target="$(uname -m)-apple-darwin"
if command -v rustup >/dev/null; then
  export RUSTUP_TOOLCHAIN="stable-$target"
  cargo --version >/dev/null 2>&1 || rustup toolchain install "$RUSTUP_TOOLCHAIN" --profile minimal
elif ! rustc -vV 2>/dev/null | grep -Fxq "host: $target" || ! command -v cargo >/dev/null; then
  echo "Installing native Rust. If setup fails, install stable-$target from rustup.rs and rerun."
  install_tool https://sh.rustup.rs -y --profile minimal --default-toolchain stable --no-modify-path
  export RUSTUP_TOOLCHAIN="stable-$target"
fi
if ! command -v uv >/dev/null; then
  echo "Installing uv. If setup fails, install uv from docs.astral.sh/uv and rerun."
  if command -v brew >/dev/null; then
    brew install uv
  else
    UV_INSTALL_DIR="$HOME/.local/bin" UV_NO_MODIFY_PATH=1 install_tool https://astral.sh/uv/install.sh
  fi
fi
uv run --no-project --managed-python --python 3.12.13 -- python -I build.py "$@"
