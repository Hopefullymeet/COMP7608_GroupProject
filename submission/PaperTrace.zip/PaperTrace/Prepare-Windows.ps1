$ErrorActionPreference = 'Stop'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
function HasCompiler {
    if (!(Test-Path $vswhere)) { return $false }
    $vs = & $vswhere -products * -version '[17.0,)' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    $kits = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows Kits\Installed Roots' -ErrorAction SilentlyContinue).KitsRoot10
    if (!$vs -or !$kits) { return $false }
    foreach ($dir in (Get-ChildItem "$kits\Lib" -Directory -ErrorAction SilentlyContinue)) {
        $libDir = $dir.FullName
        if ((Test-Path "$libDir\um\x64\kernel32.lib") -and (Test-Path "$libDir\ucrt\x64\ucrt.lib") -and (Test-Path "$kits\Include\$($dir.Name)\um\Windows.h") -and (Test-Path "$kits\bin\$($dir.Name)\x64\rc.exe")) { return $true }
    }
    return $false
}
function HasWebView {
    $key = 'Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    foreach ($root in 'HKLM:\SOFTWARE\WOW6432Node', 'HKCU:\SOFTWARE') {
        $pv = (Get-ItemProperty "$root\$key" -ErrorAction SilentlyContinue).pv
        if ($pv -and ([version]$pv -gt [version]'0.0.0.0')) { return $true }
    }
    return $false
}
function InstallPackage($id, $extraArgs, $help) {
    Write-Host $help
    if (!(Get-Command winget.exe -ErrorAction SilentlyContinue)) {
        throw "Install or update App Installer (WinGet) from the Microsoft Store, or complete the step above manually. Then rerun Build-Windows.cmd."
    }
    & winget.exe install --id $id --exact --source winget --accept-package-agreements --accept-source-agreements @extraArgs
    if ($LASTEXITCODE -ne 0) { throw "WinGet returned $LASTEXITCODE. $help Then rerun Build-Windows.cmd." }
}
if ([Runtime.InteropServices.RuntimeInformation]::OSArchitecture -ne 'X64' -or
    [Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture -ne 'X64') {
    throw 'Run this launcher from native Windows x64.'
}
if (!(HasCompiler)) {
    $help = 'In Visual Studio Installer select Desktop development with C++, MSVC x64/x86 and a Windows SDK. Approve the administrator prompt.'
    $existing = if (Test-Path $vswhere) { & $vswhere -products Microsoft.VisualStudio.Product.BuildTools -version '[17.0,18.0)' -latest -property installationPath }
    $options = '--passive --wait --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended'
    if ($existing) {
        Write-Host $help
        $setup = Join-Path (Split-Path $vswhere) 'setup.exe'
        $proc = Start-Process $setup -ArgumentList "modify --installPath `"$existing`" $($options.Replace('--wait ', ''))" -WorkingDirectory $env:TEMP -Wait -PassThru
        if ($proc.ExitCode -eq 3010) { throw 'Restart Windows, then rerun Build-Windows.cmd.' }
        if ($proc.ExitCode -ne 0) { throw "$help Then rerun Build-Windows.cmd." }
    } else {
        InstallPackage 'Microsoft.VisualStudio.2022.BuildTools' @('--override', $options) $help
    }
    if (!(HasCompiler)) { throw "$help Restart if requested, then rerun Build-Windows.cmd." }
}
if (!(HasWebView)) {
    $help = 'Install Microsoft Edge WebView2 Evergreen Runtime for Windows x64.'
    InstallPackage 'Microsoft.EdgeWebView2Runtime' @() $help
    if (!(HasWebView)) { throw "$help Then rerun Build-Windows.cmd." }
}
if (!(Get-Command rustup.exe -ErrorAction SilentlyContinue) -and !(Get-Command rustc.exe -ErrorAction SilentlyContinue)) {
    InstallPackage 'Rustlang.Rustup' @() 'Install Rustup for Windows x64.'
}
if (Get-Command rustup.exe -ErrorAction SilentlyContinue) {
    & rustup.exe run stable-x86_64-pc-windows-msvc cargo --version
    if ($LASTEXITCODE -ne 0) {
        & rustup.exe toolchain install stable-x86_64-pc-windows-msvc --profile minimal
        if ($LASTEXITCODE -ne 0) { throw 'Install stable-x86_64-pc-windows-msvc with Rustup and rerun.' }
    }
}
if (!(Get-Command uv.exe -ErrorAction SilentlyContinue)) {
    InstallPackage 'astral-sh.uv' @('--scope','user') 'Install uv for the current user.'
}
